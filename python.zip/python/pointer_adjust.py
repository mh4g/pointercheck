"""
Vibrate Mouse Game  ― 視点固定（黒背景＋赤丸）付き・列追加型 CSV ロガー
"""

import tkinter as tk
from tkinter import messagebox
import random, time, os, threading, csv
from datetime import datetime
import pyautogui
from PIL import Image, ImageTk

# ------------------  設 定  ------------------
BACKGROUND_FOLDER = "background"          # 背景画像フォルダ
CSV_FILE          = "vibrate_records.csv" # 記録用 CSV
FIXATION_RADIUS   = 30                    # 赤丸半径 [px]
# -------------------------------------------


class VibrateGame:
    # ============  初期化  ============
    def __init__(self, master, rounds=10, amplitude=5, frequency=50):
        self.master = master
        self.master.title("Vibrate Mouse Game")
        w, h = self.master.winfo_screenwidth(), self.master.winfo_screenheight()
        self.screen_size = (w, h)
        self.master.geometry(f"{w}x{h}")
        self.master.attributes("-fullscreen", True)

        # ゲーム設定
        self.rounds         = rounds
        self.amplitude      = amplitude
        self.frequency      = frequency
        self.current_round  = 0
        self.times          = []
        self.last_bg_filename = None
        self.state          = "fixation"  # fixation / vibrating / finished

        # CSV 準備（今回の列番号を取得）
        self.csv_col_idx = self._prepare_csv()

        # キャンバス
        self.canvas = tk.Canvas(self.master, width=w, height=h, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.fixation_id = None
        self.black_bg_id = None            # ★ 黒背景矩形 ID を保持

        # キー操作
        self.master.bind("<Return>", self.on_enter)
        self.master.bind("<Escape>", self.force_quit)

        # 赤丸を表示してスタートを待つ
        self._show_fixation()

    # ----------  CSV ヘルパ ----------
    def _prepare_csv(self):
        session_name = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

        if not os.path.isfile(CSV_FILE):
            with open(CSV_FILE, "w", newline="", encoding="utf-8") as f:
                wr = csv.writer(f)
                wr.writerow(["Round", session_name])
                for r in range(1, self.rounds + 1):
                    wr.writerow([r, ""])
            return 1

        with open(CSV_FILE, "r", newline="", encoding="utf-8") as f:
            rows = list(csv.reader(f))

        while len(rows) - 1 < self.rounds:
            rows.append([len(rows)] + [""] * (len(rows[0]) - 1))

        col_idx = len(rows[0])
        rows[0].append(session_name)
        for r in range(1, len(rows)):
            rows[r].append("")

        with open(CSV_FILE, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerows(rows)

        return col_idx

    def _write_round_to_csv(self, round_num, elapsed_val):
        with open(CSV_FILE, "r", newline="", encoding="utf-8") as f:
            rows = list(csv.reader(f))

        while len(rows) - 1 < round_num:
            rows.append([len(rows)] + [""] * (len(rows[0]) - 1))

        rows[round_num][self.csv_col_idx] = elapsed_val

        with open(CSV_FILE, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerows(rows)

    # ----------  背景 ----------
    def _load_random_background(self):
        imgs = [f for f in os.listdir(BACKGROUND_FOLDER)
                if os.path.isfile(os.path.join(BACKGROUND_FOLDER, f))]
        if not imgs:
            return None

        candidates = imgs
        if len(imgs) > 1 and self.last_bg_filename in imgs:
            candidates = [f for f in imgs if f != self.last_bg_filename]

        chosen = random.choice(candidates)
        self.last_bg_filename = chosen

        pil = Image.open(os.path.join(BACKGROUND_FOLDER, chosen)).resize(self.screen_size)
        return ImageTk.PhotoImage(pil)

    # ----------  ラウンド管理 ----------
    def _start_round(self):
        """背景を表示し、マウス振動を開始して計測スタート"""
        self.current_round += 1
        if self.current_round > self.rounds:
            self.show_result()
            return

        # ★ 既存の要素をすべて消去
        self.canvas.delete("all")

        bg = self._load_random_background()
        if bg:
            self.canvas.bg_img = bg
            self.canvas.create_image(0, 0, image=bg, anchor=tk.NW)

        # マウス移動＋振動開始
        w, h = self.screen_size
        cx, cy = random.randint(20, w - 20), random.randint(20, h - 20)
        pyautogui.moveTo(cx, cy)
        self._start_vibration(cx, cy)

        self.start_time = time.time()
        self.state = "vibrating"

    # ----------  振動 ----------
    def _start_vibration(self, cx, cy):
        self.vibrating = True

        def _vib():
            while self.vibrating:
                dx = random.randint(-self.amplitude, self.amplitude)
                dy = random.randint(-self.amplitude, self.amplitude)
                pyautogui.moveTo(cx + dx, cy + dy)
                time.sleep(1 / self.frequency)

        self.vib_thread = threading.Thread(target=_vib, daemon=True)
        self.vib_thread.start()

    def _stop_vibration(self):
        self.vibrating = False
        if getattr(self, "vib_thread", None) and self.vib_thread.is_alive():
            self.vib_thread.join(timeout=0.1)

    # ----------  赤丸 ----------
    def _show_fixation(self):
        """黒背景に赤丸を描画"""
        self.canvas.delete("all")                     # ★ キャンバスをクリア
        w, h = self.screen_size
        # ★ 黒い矩形で全画面を塗りつぶす
        self.black_bg_id = self.canvas.create_rectangle(
            0, 0, w, h, fill="black", outline=""
        )
        cx, cy = w // 2, h // 2
        r = FIXATION_RADIUS
        self.fixation_id = self.canvas.create_oval(
            cx - r, cy - r, cx + r, cy + r, fill="red", outline=""
        )
        self.state = "fixation"

    def _hide_fixation(self):
        if self.fixation_id:
            self.canvas.delete(self.fixation_id)
            self.fixation_id = None
        if self.black_bg_id:
            self.canvas.delete(self.black_bg_id)
            self.black_bg_id = None

    # ----------  キー操作 ----------
    def on_enter(self, _event=None):
        if self.state == "fixation":
            self._hide_fixation()
            self._start_round()

        elif self.state == "vibrating":
            elapsed = time.time() - self.start_time
            self.times.append(elapsed)
            self._write_round_to_csv(self.current_round, round(elapsed, 6))

            self._stop_vibration()

            if self.current_round >= self.rounds:
                self.show_result()
            else:
                self._show_fixation()

    def force_quit(self, _event=None):
        self._stop_vibration()
        self.master.quit()

    # ----------  結果 ----------
    def show_result(self):
        if self.state == "finished":
            return
        self.state = "finished"
        avg = sum(self.times) / len(self.times) if self.times else 0
        txt = (f"全 {self.rounds} 回の記録: {[round(t,3) for t in self.times]}\n\n"
               f"平均時間: {round(avg,3)} 秒")
        messagebox.showinfo("結果", txt)
        self.master.quit()


def main():
    # pyautogui.FAILSAFE = False  # 緊急停止を無効にしたい場合
    root = tk.Tk()
    VibrateGame(root, rounds=30, amplitude=1, frequency=10)
    root.mainloop()


if __name__ == "__main__":
    main()
